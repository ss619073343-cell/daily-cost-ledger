import SwiftUI

@main
struct DailyCostLedgerApp: App {
    var body: some Scene {
        WindowGroup { ContentView() }
    }
}
