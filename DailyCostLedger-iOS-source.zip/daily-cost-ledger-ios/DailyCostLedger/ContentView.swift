import SwiftUI

struct Product: Identifiable, Codable, Equatable {
    var id = UUID()
    var name: String
    var category: Category
    var price: Double
    var purchaseDate: Date
    var isPinned: Bool? = false
    var sortOrder: Int? = nil
    var daysOwned: Int {
        max(1, Calendar.current.dateComponents([.day], from: Calendar.current.startOfDay(for: purchaseDate), to: Calendar.current.startOfDay(for: .now)).day.map { $0 + 1 } ?? 1)
    }
    var dailyCost: Double { price / Double(daysOwned) }
}

enum Category: String, Codable, CaseIterable, Identifiable {
    case phone = "手机", tablet = "平板", computer = "电脑与配件", camera = "相机与影像"
    case audio = "耳机与音响", wearable = "智能穿戴", gaming = "游戏娱乐"
    case appliance = "家用电器", home = "家具家居", travel = "工具出行", other = "其他"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .phone: "iphone"
        case .tablet: "ipad"
        case .computer: "laptopcomputer"
        case .camera: "camera"
        case .audio: "headphones"
        case .wearable: "applewatch"
        case .gaming: "gamecontroller"
        case .appliance: "bolt"
        case .home: "house"
        case .travel: "bicycle"
        case .other: "shippingbox"
        }
    }

    init(from decoder: Decoder) throws {
        let value = try decoder.singleValueContainer().decode(String.self)
        self = value == "手机与平板" ? .phone : (Category(rawValue: value) ?? .other)
    }
}

@MainActor final class ProductStore: ObservableObject {
    @Published var products: [Product] = [] { didSet { save() } }
    private let key = "daily-cost-ledger-products-v2"
    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode([Product].self, from: data) { products = saved }
    }
    private func save() {
        if let data = try? JSONEncoder().encode(products) { UserDefaults.standard.set(data, forKey: key) }
    }
}

struct ContentView: View {
    @StateObject private var store = ProductStore()
    @State private var showingAdd = false
    @State private var selectedProduct: Product?
    @State private var isSorting = false
    private let paper = Color(red: 0.965, green: 0.957, blue: 0.925)
    private let ink = Color(red: 0.14, green: 0.14, blue: 0.125)
    private let accent = Color(red: 0.58, green: 0.16, blue: 0.12)
    private var total: Double { store.products.reduce(0) { $0 + $1.price } }
    private var daily: Double { store.products.reduce(0) { $0 + $1.dailyCost } }
    private var sorted: [Product] {
        store.products.sorted {
            if ($0.isPinned ?? false) != ($1.isPinned ?? false) { return $0.isPinned ?? false }
            let leftOrder = $0.sortOrder ?? Int.max
            let rightOrder = $1.sortOrder ?? Int.max
            if leftOrder != rightOrder { return leftOrder < rightOrder }
            return $0.purchaseDate > $1.purchaseDate
        }
    }

    var body: some View {
        ZStack {
            paper.ignoresSafeArea()
            ScrollView {
                LazyVStack(spacing: 0) {
                    header
                    summary
                    productList
                }
                .padding(.horizontal, 22)
                .padding(.bottom, 124)
            }
            .scrollIndicators(.hidden)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) { bottomButton }
        .sheet(isPresented: $showingAdd) {
            AddProductView { store.products.append($0) }
                .presentationDetents([.large])
                .presentationDragIndicator(.visible)
        }
        .sheet(item: $selectedProduct) { product in
            ProductDetailView(product: product, ink: ink, accent: accent) { updatedProduct in
                guard let index = store.products.firstIndex(where: { $0.id == updatedProduct.id }) else { return }
                store.products[index] = updatedProduct
            }
                .presentationDetents([.medium])
                .presentationDragIndicator(.visible)
        }
        .tint(accent)
    }

    private var header: some View {
        HStack(alignment: .bottom) {
            VStack(alignment: .leading, spacing: 7) {
                Text("DAILY OBJECTS").font(.system(size: 11, weight: .semibold)).tracking(2.1).foregroundStyle(accent)
                Text("日用成本簿").font(.system(size: 34, weight: .medium, design: .serif)).foregroundStyle(ink)
                Text(Date.now.formatted(.dateTime.year().month().day().locale(Locale(identifier: "zh_CN"))))
                    .font(.system(size: 13)).foregroundStyle(ink.opacity(0.48))
            }
            Spacer()
            VStack(alignment: .trailing, spacing: 3) {
                Text("物品").font(.system(size: 12)).foregroundStyle(ink.opacity(0.45))
                Text("\(store.products.count)").font(.system(size: 30, weight: .light, design: .rounded)).foregroundStyle(ink)
            }
        }
        .padding(.top, 25).padding(.bottom, 29)
    }

    private var summary: some View {
        VStack(spacing: 18) {
            HStack(alignment: .firstTextBaseline) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("今日平均花费").font(.system(size: 13)).foregroundStyle(ink.opacity(0.5))
                    Text(daily, format: .currency(code: "CNY").precision(.fractionLength(2)))
                        .font(.system(size: 32, weight: .medium, design: .rounded)).foregroundStyle(ink)
                }
                Spacer()
                Text("/ 天").font(.system(size: 13)).foregroundStyle(ink.opacity(0.45))
            }
            Rectangle().fill(ink.opacity(0.12)).frame(height: 0.5)
            HStack {
                metric("累计购入", total.formatted(.currency(code: "CNY").precision(.fractionLength(0))))
                Spacer()
                metric("时间正在", "摊薄成本", alignment: .trailing)
            }
        }
        .padding(21)
        .background(Color.white.opacity(0.46), in: RoundedRectangle(cornerRadius: 3))
        .overlay(RoundedRectangle(cornerRadius: 3).stroke(ink.opacity(0.08), lineWidth: 0.5))
    }

    private func metric(_ title: String, _ value: String, alignment: HorizontalAlignment = .leading) -> some View {
        VStack(alignment: alignment, spacing: 4) {
            Text(title).font(.system(size: 12)).foregroundStyle(ink.opacity(0.45))
            Text(value).font(.system(size: 15, weight: .medium)).foregroundStyle(ink.opacity(0.85))
        }
    }

    private func togglePin(_ product: Product) {
        guard let index = store.products.firstIndex(where: { $0.id == product.id }) else { return }
        store.products[index].isPinned = !(store.products[index].isPinned ?? false)
    }

    private func delete(_ product: Product) {
        store.products.removeAll { $0.id == product.id }
    }

    private func move(_ product: Product, by delta: Int) {
        guard delta != 0 else { return }
        var display = sorted
        guard let current = display.firstIndex(where: { $0.id == product.id }) else { return }
        let destination = current + delta
        guard display.indices.contains(destination),
              (display[current].isPinned ?? false) == (display[destination].isPinned ?? false) else { return }
        display.swapAt(current, destination)
        let positions = Dictionary(uniqueKeysWithValues: display.enumerated().map { ($0.element.id, $0.offset) })
        for index in store.products.indices { store.products[index].sortOrder = positions[store.products[index].id] }
    }

    @ViewBuilder private var productList: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                Text("正在使用").font(.system(size: 16, weight: .medium)).foregroundStyle(ink)
                Spacer()
                Button(isSorting ? "完成" : "排序") { isSorting.toggle() }
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(isSorting ? accent : ink.opacity(0.5))
            }
            .padding(.top, 34).padding(.bottom, 12)

            if sorted.isEmpty {
                VStack(spacing: 13) {
                    Image(systemName: "square.dashed").font(.system(size: 27, weight: .light)).foregroundStyle(ink.opacity(0.35))
                    Text("还没有记录物品").font(.system(size: 15, weight: .medium)).foregroundStyle(ink.opacity(0.7))
                    Text("从一件每天都在使用的物品开始").font(.system(size: 13)).foregroundStyle(ink.opacity(0.4))
                }
                .frame(maxWidth: .infinity).padding(.vertical, 58)
            } else {
                VStack(spacing: 10) {
                    ForEach(sorted) { product in
                        HStack(spacing: 9) {
                            SwipeableProductRow(product: product, ink: ink, accent: accent, onOpen: { selectedProduct = product }, onTogglePin: { togglePin(product) }, onDelete: { delete(product) })
                            if isSorting {
                                ReorderHandle(ink: ink) { step in move(product, by: step) }
                            }
                        }
                    }
                }
                .padding(.bottom, 8)
            }
        }
    }

    private var bottomButton: some View {
        VStack(spacing: 0) {
            LinearGradient(colors: [paper.opacity(0), paper], startPoint: .top, endPoint: .bottom).frame(height: 28)
            Button { showingAdd = true } label: {
                Label("添加产品", systemImage: "plus")
                    .font(.system(size: 16, weight: .semibold)).frame(maxWidth: .infinity).padding(.vertical, 16)
            }
            .modifier(LiquidGlassButton(accent: accent))
            .padding(.horizontal, 22).padding(.bottom, 10)
        }
        .background(paper)
    }
}

struct ProductRow: View {
    let product: Product
    let ink: Color
    let accent: Color
    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: product.category.symbol)
                .font(.system(size: 18)).foregroundStyle(ink.opacity(0.74)).frame(width: 42, height: 42)
                .background(ink.opacity(0.055), in: RoundedRectangle(cornerRadius: 4))
            VStack(alignment: .leading, spacing: 4) {
                HStack(spacing: 5) {
                    Text(product.name).font(.system(size: 16, weight: .medium)).foregroundStyle(ink).lineLimit(1)
                    if product.isPinned ?? false { Image(systemName: "pin.fill").font(.system(size: 10)).foregroundStyle(accent) }
                }
                Text("\(product.category.rawValue) · \(product.daysOwned) 天").font(.system(size: 12)).foregroundStyle(ink.opacity(0.43))
            }
            Spacer(minLength: 8)
            VStack(alignment: .trailing, spacing: 4) {
                Text(product.dailyCost, format: .currency(code: "CNY").precision(.fractionLength(2)))
                    .font(.system(size: 16, weight: .medium, design: .rounded)).foregroundStyle(accent)
                Text("每天").font(.system(size: 11)).foregroundStyle(ink.opacity(0.38))
            }
            Image(systemName: "chevron.right")
                .font(.system(size: 11, weight: .semibold))
                .foregroundStyle(ink.opacity(0.28))
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 14)
        .modifier(LiquidGlassProductCard(ink: ink))
    }
}

struct SwipeableProductRow: View {
    let product: Product
    let ink: Color
    let accent: Color
    let onOpen: () -> Void
    let onTogglePin: () -> Void
    let onDelete: () -> Void
    @State private var dragOffset: CGFloat = 0
    @State private var revealedAction: SwipeAction?
    @State private var shouldIgnoreTap = false
    private let pinTint = Color(red: 0.95, green: 0.57, blue: 0.11)

    private enum SwipeAction { case pin, delete }
    private var restingOffset: CGFloat {
        switch revealedAction {
        case .pin: 108
        case .delete: -108
        case nil: 0
        }
    }

    var body: some View {
        ZStack {
            if revealedAction == .pin || dragOffset > 0 {
                Button {
                    onTogglePin()
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) { revealedAction = nil }
                } label: {
                    Label(product.isPinned ?? false ? "取消置顶" : "置顶", systemImage: product.isPinned ?? false ? "pin.slash" : "pin.fill")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 100)
                        .frame(maxHeight: .infinity)
                        .modifier(LiquidGlassSwipeAction(tint: pinTint))
                }
                .buttonStyle(.plain)
                .frame(maxWidth: .infinity, alignment: .leading)
            }

            if revealedAction == .delete || dragOffset < 0 {
                Button {
                    onDelete()
                } label: {
                    Label("删除", systemImage: "trash")
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 100)
                        .frame(maxHeight: .infinity)
                        .modifier(LiquidGlassSwipeAction(tint: .red))
                }
                .buttonStyle(.plain)
                .frame(maxWidth: .infinity, alignment: .trailing)
            }

            Button {
                guard !shouldIgnoreTap else { return }
                // Button actions can arrive before a simultaneous drag has fully
                // resolved. A brief defer lets a horizontal swipe claim the gesture.
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
                    guard !shouldIgnoreTap else { return }
                    onOpen()
                }
            } label: {
                ProductRow(product: product, ink: ink, accent: accent)
            }
            .buttonStyle(.plain)
            .frame(maxWidth: .infinity)
            .offset(x: restingOffset + dragOffset)
            .simultaneousGesture(
                DragGesture(minimumDistance: 8)
                    .onChanged { value in
                        guard abs(value.translation.width) > abs(value.translation.height) else { return }
                        if abs(value.translation.width) > 8 { shouldIgnoreTap = true }
                        switch revealedAction {
                        case .pin:
                            // An exposed left-side action can only be dragged back closed.
                            dragOffset = max(-108, min(0, value.translation.width))
                        case .delete:
                            // An exposed right-side action can only be dragged back closed.
                            dragOffset = max(0, min(108, value.translation.width))
                        case nil:
                            dragOffset = max(-108, min(108, value.translation.width))
                        }
                    }
                    .onEnded { value in
                        guard abs(value.translation.width) > abs(value.translation.height) else { return }
                        withAnimation(.spring(response: 0.28, dampingFraction: 0.85)) {
                            switch revealedAction {
                            case .pin:
                                revealedAction = value.translation.width < -48 ? nil : .pin
                            case .delete:
                                revealedAction = value.translation.width > 48 ? nil : .delete
                            case nil:
                                if value.translation.width > 48 {
                                    revealedAction = .pin
                                } else if value.translation.width < -48 {
                                    revealedAction = .delete
                                }
                            }
                            dragOffset = 0
                        }
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) { shouldIgnoreTap = false }
                    }
            )
        }
        .frame(maxWidth: .infinity)
        .clipShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
    }
}

struct LiquidGlassSwipeAction: ViewModifier {
    let tint: Color

    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content
                .background(tint.opacity(0.72), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .glassEffect(.regular.interactive(), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        } else {
            content
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .background(tint.opacity(0.72), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        }
    }
}

struct ReorderHandle: View {
    let ink: Color
    let onMove: (Int) -> Void
    @State private var dragTranslation: CGFloat = 0
    @State private var lastStep = 0
    @GestureState private var isPressing = false

    var body: some View {
        Image(systemName: "line.3.horizontal")
            .font(.system(size: 14, weight: .bold))
            .foregroundStyle(ink.opacity(isPressing ? 0.88 : 0.55))
            .frame(width: 38, height: 66)
            .modifier(LiquidGlassSortControl(ink: ink))
            .scaleEffect(isPressing ? 1.08 : 1)
            .offset(y: isPressing ? dragTranslation * 0.18 : 0)
            .animation(.spring(response: 0.24, dampingFraction: 0.78), value: isPressing)
            .gesture(
                LongPressGesture(minimumDuration: 0.28)
                    .updating($isPressing) { value, state, _ in state = value }
                    .sequenced(before: DragGesture())
                    .onChanged { value in
                        guard case .second(true, let drag?) = value else { return }
                        dragTranslation = drag.translation.height
                        let step = Int((drag.translation.height / 58).rounded(.towardZero))
                        if step != lastStep {
                            onMove(step - lastStep)
                            lastStep = step
                        }
                    }
                    .onEnded { _ in
                        withAnimation(.spring(response: 0.25, dampingFraction: 0.82)) { dragTranslation = 0 }
                        lastStep = 0
                    }
            )
            .accessibilityLabel("长按并上下拖动调整排序")
    }
}

struct LiquidGlassProductCard: ViewModifier {
    let ink: Color

    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content
                .glassEffect(.regular.interactive(), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        } else {
            content
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
                .overlay(
                    RoundedRectangle(cornerRadius: 18, style: .continuous)
                        .stroke(Color.white.opacity(0.58), lineWidth: 0.8)
                )
                .shadow(color: ink.opacity(0.05), radius: 12, y: 5)
        }
    }
}

struct LiquidGlassSortControl: ViewModifier {
    let ink: Color

    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content
                .glassEffect(.regular.interactive(), in: Capsule())
        } else {
            content
                .background(.ultraThinMaterial, in: Capsule())
                .overlay(Capsule().stroke(Color.white.opacity(0.62), lineWidth: 0.8))
                .shadow(color: ink.opacity(0.06), radius: 8, y: 3)
        }
    }
}

struct ProductDetailView: View {
    @Environment(\.dismiss) private var dismiss
    let product: Product
    let ink: Color
    let accent: Color
    let onSave: (Product) -> Void
    @State private var name: String
    @State private var category: Category
    @State private var priceText: String
    @State private var purchaseDate: Date
    private let paper = Color(red: 0.965, green: 0.957, blue: 0.925)

    init(product: Product, ink: Color, accent: Color, onSave: @escaping (Product) -> Void) {
        self.product = product
        self.ink = ink
        self.accent = accent
        self.onSave = onSave
        _name = State(initialValue: product.name)
        _category = State(initialValue: product.category)
        _priceText = State(initialValue: product.price.formatted(.number.precision(.fractionLength(2))))
        _purchaseDate = State(initialValue: product.purchaseDate)
    }

    private var updatedPrice: Double? {
        Double(priceText.replacingOccurrences(of: ",", with: "."))
    }

    private var daysForSelectedDate: Int {
        max(1, Calendar.current.dateComponents([.day], from: Calendar.current.startOfDay(for: purchaseDate), to: Calendar.current.startOfDay(for: .now)).day.map { $0 + 1 } ?? 1)
    }

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 0) {
                HStack(spacing: 15) {
                    Image(systemName: category.symbol)
                        .font(.system(size: 25, weight: .light))
                        .foregroundStyle(ink)
                        .frame(width: 58, height: 58)
                        .background(ink.opacity(0.06), in: RoundedRectangle(cornerRadius: 7))
                    VStack(alignment: .leading, spacing: 5) {
                        Text("编辑产品信息").font(.system(size: 13)).foregroundStyle(ink.opacity(0.48))
                        Text(name.isEmpty ? "未命名设备" : name).font(.system(size: 24, weight: .medium, design: .serif)).foregroundStyle(ink)
                    }
                }
                .padding(.bottom, 31)

                VStack(spacing: 0) {
                    TextField("设备名称", text: $name)
                        .font(.system(size: 16, weight: .medium))
                        .foregroundStyle(ink)
                        .padding(.vertical, 17)
                    Divider().overlay(ink.opacity(0.1))
                    Picker("设备类型", selection: $category) {
                        ForEach(Category.allCases) { category in
                            Label(category.rawValue, systemImage: category.symbol).tag(category)
                        }
                    }
                    .font(.system(size: 14))
                    .tint(accent)
                    .padding(.vertical, 9)
                    Divider().overlay(ink.opacity(0.1))
                    HStack {
                        Text("购入价格").font(.system(size: 14)).foregroundStyle(ink.opacity(0.5))
                        Spacer()
                        Text("¥").font(.system(size: 16, weight: .semibold, design: .rounded)).foregroundStyle(accent)
                        TextField("价格", text: $priceText)
                            .keyboardType(.decimalPad)
                            .multilineTextAlignment(.trailing)
                            .font(.system(size: 16, weight: .semibold, design: .rounded))
                            .foregroundStyle(accent)
                            .frame(width: 118)
                    }
                    .padding(.vertical, 17)
                    Divider().overlay(ink.opacity(0.1))
                    DatePicker("购入日期", selection: $purchaseDate, in: ...Date.now, displayedComponents: .date)
                        .font(.system(size: 14))
                        .foregroundStyle(ink)
                        .padding(.vertical, 10)
                    Divider().overlay(ink.opacity(0.1))
                    detailRow("已使用", "\(daysForSelectedDate) 天")
                }
                .padding(.horizontal, 17)
                .background(Color.white.opacity(0.48), in: RoundedRectangle(cornerRadius: 5))
                .overlay(RoundedRectangle(cornerRadius: 5).stroke(ink.opacity(0.08), lineWidth: 0.5))

                Spacer()
            }
            .padding(22)
            .background(paper.ignoresSafeArea())
            .navigationTitle("产品信息")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        guard let price = updatedPrice, price > 0 else { return }
                        var updated = product
                        updated.name = name.trimmingCharacters(in: .whitespacesAndNewlines)
                        updated.category = category
                        updated.price = price
                        updated.purchaseDate = purchaseDate
                        onSave(updated)
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || (updatedPrice ?? 0) <= 0)
                    .tint(accent)
                }
            }
        }
    }

    private func detailRow(_ title: String, _ value: String, emphasized: Bool = false) -> some View {
        HStack {
            Text(title).font(.system(size: 14)).foregroundStyle(ink.opacity(0.5))
            Spacer()
            Text(value)
                .font(.system(size: 16, weight: emphasized ? .semibold : .medium, design: .rounded))
                .foregroundStyle(emphasized ? accent : ink)
        }
        .padding(.vertical, 17)
    }
}

struct LiquidGlassButton: ViewModifier {
    let accent: Color
    @ViewBuilder func body(content: Content) -> some View {
        if #available(iOS 26.0, *) {
            content.foregroundStyle(.white).glassEffect(.regular.tint(accent).interactive(), in: Capsule())
        } else {
            content.foregroundStyle(.white).background(.ultraThinMaterial, in: Capsule()).background(accent.opacity(0.92), in: Capsule())
        }
    }
}

struct AddProductView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""
    @State private var category: Category = .phone
    @State private var price = ""
    @State private var date = Date.now
    let onSave: (Product) -> Void
    private let paper = Color(red: 0.965, green: 0.957, blue: 0.925)
    private var value: Double? { Double(price.replacingOccurrences(of: ",", with: ".")) }

    var body: some View {
        NavigationStack {
            Form {
                Section("物品") {
                    TextField("名称", text: $name)
                    Picker("类别", selection: $category) { ForEach(Category.allCases) { Text($0.rawValue).tag($0) } }
                }
                Section("购入信息") {
                    TextField("价格", text: $price).keyboardType(.decimalPad)
                    DatePicker("购入日期", selection: $date, in: ...Date.now, displayedComponents: .date)
                }
                Section { Text("购入当天按使用 1 天计算，之后每日自动更新平均花费。").font(.system(size: 12)).foregroundStyle(.secondary) }
            }
            .scrollContentBackground(.hidden).background(paper)
            .navigationTitle("添加产品").navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) { Button("取消") { dismiss() } }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        guard let priceValue = value else { return }
                        onSave(Product(name: name.trimmingCharacters(in: .whitespacesAndNewlines), category: category, price: priceValue, purchaseDate: date))
                        dismiss()
                    }
                    .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || (value ?? 0) <= 0)
                }
            }
        }
    }
}

#Preview { ContentView() }
