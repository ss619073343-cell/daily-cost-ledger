# 日用成本簿 iPhone App

## 用 Xcode 安装到 iPhone

1. 双击 `DailyCostLedger.xcodeproj` 打开工程。
2. 在 Xcode 顶部选择你的 iPhone（通过线缆连接，或启用无线调试）。
3. 打开 Target `DailyCostLedger` 的 **Signing & Capabilities**，在 **Team** 选择你的 Apple ID。
4. 如出现 Bundle Identifier 冲突，把 `com.ss619073343.dailycostledger` 改成你的唯一标识。
5. 点击左上角运行按钮（▶）安装到手机。

首次在免费 Apple ID 上安装时，iPhone 会要求在“设置 > 通用 > VPN 与设备管理”中信任开发者。应用需联网加载网页；数据保存于这台 iPhone 的 App 本地存储中。
